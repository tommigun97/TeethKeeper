﻿INSERT INTO PAZIENTE (Nome, Cognome, CodFiscale, Telefono, Sesso, Via, NumeroCivico, Città, CAP, CittaNascita, DataNascita)
VALUES ('Tommaso', 'Ghini', 'GHNTMM97E43D468R', '0543 531742', 'M', 'Fintone', '98', 'Forli', '48017', 'Forli', '24/03/1997' );
/*dobbiamo sistemare questa query per inserimenti futuri*/