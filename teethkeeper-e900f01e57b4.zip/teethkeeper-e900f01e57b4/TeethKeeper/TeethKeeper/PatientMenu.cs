﻿using System;
using System.Windows.Forms;

namespace TeethKeeper
{
    public partial class PatientMenu : Form
    {

        private string code = null;

        public PatientMenu()
        {
            InitializeComponent();
        }

        private void Patient_Load(object sender, EventArgs e)
        {
            pAZIENTETableAdapter.Fill(tkDataBaseDataSet.PAZIENTE);
        }

        private void srhButton_Click(object sender, EventArgs e)
        {
            if(searchBox.Text != "")
            {
                pAZIENTETableAdapter.FillSurname(tkDataBaseDataSet.PAZIENTE, searchBox.Text);
            }
            else
            {
                pAZIENTETableAdapter.Fill(tkDataBaseDataSet.PAZIENTE);
            }
        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            new InsertMenu().Show();
            Hide();
        }

        private void pAZIENTEDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            code = pAZIENTEDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            if (code != null && code.Length == 16)
                {
                    if (schedA_CLINICATableAdapter.CheckCode(code) > 0)
                    {
                     DialogResult result = MessageBox.Show("Visualizzare la scheda clinica?", "Scelta", MessageBoxButtons.YesNoCancel);
                        if (result == DialogResult.Yes)
                        {
                            new ClinicalCard(code).Show();
                            Hide();
                        }
                        if (result == DialogResult.No)
                        {
                            new AppointementMenu(code).Show();
                            Hide();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cella Non Valida", "Errore di ricerca", MessageBoxButtons.OK);
                    }
                }
            
        }

        
    }
}





