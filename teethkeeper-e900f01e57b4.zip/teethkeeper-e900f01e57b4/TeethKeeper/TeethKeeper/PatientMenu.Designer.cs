﻿namespace TeethKeeper
{
    partial class PatientMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PatientMenu));
            this.pAZIENTEDataGridView = new System.Windows.Forms.DataGridView();
            this.nomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cognomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codFiscaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sessoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroCivicoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cittàDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cAPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cittaNascitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataNascitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pAZIENTEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tkDataBaseDataSet = new TeethKeeper.TKDataBaseDataSet();
            this.srhButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.insertButton = new System.Windows.Forms.Button();
            this.pAZIENTETableAdapter = new TeethKeeper.TKDataBaseDataSetTableAdapters.PAZIENTETableAdapter();
            this.schedA_CLINICATableAdapter = new TeethKeeper.TKDataBaseDataSetTableAdapters.SCHEDA_CLINICATableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pAZIENTEDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAZIENTEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tkDataBaseDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // pAZIENTEDataGridView
            // 
            this.pAZIENTEDataGridView.AllowUserToAddRows = false;
            this.pAZIENTEDataGridView.AllowUserToDeleteRows = false;
            this.pAZIENTEDataGridView.AutoGenerateColumns = false;
            this.pAZIENTEDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pAZIENTEDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nomeDataGridViewTextBoxColumn,
            this.cognomeDataGridViewTextBoxColumn,
            this.codFiscaleDataGridViewTextBoxColumn,
            this.telefonoDataGridViewTextBoxColumn,
            this.sessoDataGridViewTextBoxColumn,
            this.viaDataGridViewTextBoxColumn,
            this.numeroCivicoDataGridViewTextBoxColumn,
            this.cittàDataGridViewTextBoxColumn,
            this.cAPDataGridViewTextBoxColumn,
            this.cittaNascitaDataGridViewTextBoxColumn,
            this.dataNascitaDataGridViewTextBoxColumn});
            this.pAZIENTEDataGridView.DataSource = this.pAZIENTEBindingSource;
            this.pAZIENTEDataGridView.Location = new System.Drawing.Point(13, 129);
            this.pAZIENTEDataGridView.Name = "pAZIENTEDataGridView";
            this.pAZIENTEDataGridView.ReadOnly = true;
            this.pAZIENTEDataGridView.Size = new System.Drawing.Size(1143, 485);
            this.pAZIENTEDataGridView.TabIndex = 1;
            this.pAZIENTEDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.pAZIENTEDataGridView_CellContentClick);
            // 
            // nomeDataGridViewTextBoxColumn
            // 
            this.nomeDataGridViewTextBoxColumn.DataPropertyName = "Nome";
            this.nomeDataGridViewTextBoxColumn.HeaderText = "Nome";
            this.nomeDataGridViewTextBoxColumn.Name = "nomeDataGridViewTextBoxColumn";
            this.nomeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cognomeDataGridViewTextBoxColumn
            // 
            this.cognomeDataGridViewTextBoxColumn.DataPropertyName = "Cognome";
            this.cognomeDataGridViewTextBoxColumn.HeaderText = "Cognome";
            this.cognomeDataGridViewTextBoxColumn.Name = "cognomeDataGridViewTextBoxColumn";
            this.cognomeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // codFiscaleDataGridViewTextBoxColumn
            // 
            this.codFiscaleDataGridViewTextBoxColumn.DataPropertyName = "CodFiscale";
            this.codFiscaleDataGridViewTextBoxColumn.HeaderText = "CodFiscale";
            this.codFiscaleDataGridViewTextBoxColumn.Name = "codFiscaleDataGridViewTextBoxColumn";
            this.codFiscaleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // telefonoDataGridViewTextBoxColumn
            // 
            this.telefonoDataGridViewTextBoxColumn.DataPropertyName = "Telefono";
            this.telefonoDataGridViewTextBoxColumn.HeaderText = "Telefono";
            this.telefonoDataGridViewTextBoxColumn.Name = "telefonoDataGridViewTextBoxColumn";
            this.telefonoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sessoDataGridViewTextBoxColumn
            // 
            this.sessoDataGridViewTextBoxColumn.DataPropertyName = "Sesso";
            this.sessoDataGridViewTextBoxColumn.HeaderText = "Sesso";
            this.sessoDataGridViewTextBoxColumn.Name = "sessoDataGridViewTextBoxColumn";
            this.sessoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viaDataGridViewTextBoxColumn
            // 
            this.viaDataGridViewTextBoxColumn.DataPropertyName = "Via";
            this.viaDataGridViewTextBoxColumn.HeaderText = "Via";
            this.viaDataGridViewTextBoxColumn.Name = "viaDataGridViewTextBoxColumn";
            this.viaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // numeroCivicoDataGridViewTextBoxColumn
            // 
            this.numeroCivicoDataGridViewTextBoxColumn.DataPropertyName = "NumeroCivico";
            this.numeroCivicoDataGridViewTextBoxColumn.HeaderText = "NumeroCivico";
            this.numeroCivicoDataGridViewTextBoxColumn.Name = "numeroCivicoDataGridViewTextBoxColumn";
            this.numeroCivicoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cittàDataGridViewTextBoxColumn
            // 
            this.cittàDataGridViewTextBoxColumn.DataPropertyName = "Città";
            this.cittàDataGridViewTextBoxColumn.HeaderText = "Città";
            this.cittàDataGridViewTextBoxColumn.Name = "cittàDataGridViewTextBoxColumn";
            this.cittàDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cAPDataGridViewTextBoxColumn
            // 
            this.cAPDataGridViewTextBoxColumn.DataPropertyName = "CAP";
            this.cAPDataGridViewTextBoxColumn.HeaderText = "CAP";
            this.cAPDataGridViewTextBoxColumn.Name = "cAPDataGridViewTextBoxColumn";
            this.cAPDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cittaNascitaDataGridViewTextBoxColumn
            // 
            this.cittaNascitaDataGridViewTextBoxColumn.DataPropertyName = "CittaNascita";
            this.cittaNascitaDataGridViewTextBoxColumn.HeaderText = "CittaNascita";
            this.cittaNascitaDataGridViewTextBoxColumn.Name = "cittaNascitaDataGridViewTextBoxColumn";
            this.cittaNascitaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataNascitaDataGridViewTextBoxColumn
            // 
            this.dataNascitaDataGridViewTextBoxColumn.DataPropertyName = "DataNascita";
            this.dataNascitaDataGridViewTextBoxColumn.HeaderText = "DataNascita";
            this.dataNascitaDataGridViewTextBoxColumn.Name = "dataNascitaDataGridViewTextBoxColumn";
            this.dataNascitaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pAZIENTEBindingSource
            // 
            this.pAZIENTEBindingSource.DataMember = "PAZIENTE";
            this.pAZIENTEBindingSource.DataSource = this.tkDataBaseDataSet;
            // 
            // tkDataBaseDataSet
            // 
            this.tkDataBaseDataSet.DataSetName = "TKDataBaseDataSet";
            this.tkDataBaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // srhButton
            // 
            this.srhButton.Location = new System.Drawing.Point(144, 68);
            this.srhButton.Name = "srhButton";
            this.srhButton.Size = new System.Drawing.Size(86, 32);
            this.srhButton.TabIndex = 2;
            this.srhButton.Text = "Invio";
            this.srhButton.UseVisualStyleBackColor = true;
            this.srhButton.Click += new System.EventHandler(this.srhButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ricerca";
            // 
            // searchBox
            // 
            this.searchBox.Location = new System.Drawing.Point(17, 75);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(100, 20);
            this.searchBox.TabIndex = 4;
            // 
            // insertButton
            // 
            this.insertButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insertButton.Location = new System.Drawing.Point(1077, 56);
            this.insertButton.Name = "insertButton";
            this.insertButton.Size = new System.Drawing.Size(79, 44);
            this.insertButton.TabIndex = 6;
            this.insertButton.Text = "Inserisci Paziente";
            this.insertButton.UseVisualStyleBackColor = true;
            this.insertButton.Click += new System.EventHandler(this.InsertButton_Click);
            // 
            // pAZIENTETableAdapter
            // 
            this.pAZIENTETableAdapter.ClearBeforeFill = true;
            // 
            // schedA_CLINICATableAdapter
            // 
            this.schedA_CLINICATableAdapter.ClearBeforeFill = true;
            // 
            // PatientMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(1168, 626);
            this.Controls.Add(this.insertButton);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.srhButton);
            this.Controls.Add(this.pAZIENTEDataGridView);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PatientMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TeethKeeper";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Patient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pAZIENTEDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAZIENTEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tkDataBaseDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView pAZIENTEDataGridView;
        private System.Windows.Forms.Button srhButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox searchBox;
        private TKDataBaseDataSetTableAdapters.PAZIENTETableAdapter pAZIENTETableAdapter;
        private System.Windows.Forms.Button insertButton;
        private TKDataBaseDataSet tkDataBaseDataSet;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cognomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codFiscaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sessoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn viaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroCivicoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cittàDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cAPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cittaNascitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataNascitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource pAZIENTEBindingSource;
        private TKDataBaseDataSetTableAdapters.SCHEDA_CLINICATableAdapter schedA_CLINICATableAdapter;
    }
}