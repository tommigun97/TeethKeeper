﻿namespace TeethKeeper
{
}

namespace TeethKeeper
{


    public partial class TKDataBaseDataSet
    {
        partial class PAZIENTEDataTable
        {
        }
    }
}

namespace TeethKeeper.TKDataBaseDataSetTableAdapters
{
    partial class PAZIENTETableAdapter
    {
    }

    public partial class ATTREZZATURATableAdapter {
    }
}
