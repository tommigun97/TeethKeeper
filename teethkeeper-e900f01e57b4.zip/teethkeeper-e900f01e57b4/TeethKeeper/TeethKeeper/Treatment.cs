﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeethKeeper
{
    public partial class Treatment : Form
    {
        private String codPaziente;
        public Treatment(string cod)
        {
            this.codPaziente = cod;
            InitializeComponent();
        }

        private void Treatment_Load(object sender, EventArgs e)
        {

        }
    }
}
